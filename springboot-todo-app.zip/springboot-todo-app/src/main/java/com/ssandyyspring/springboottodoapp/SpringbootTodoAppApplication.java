package com.ssandyyspring.springboottodoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootTodoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootTodoAppApplication.class, args);
	}

}
